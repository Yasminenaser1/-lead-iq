import { NextResponse } from 'next/server';
import getDb from '@/lib/db';

export async function PATCH(request, { params }) {
  try {
    const body = await request.json();
    const db = getDb();

    const allowed = ['status', 'score', 'score_reason', 'notes'];
    const entries = Object.entries(body).filter(([k]) => allowed.includes(k));

    if (entries.length === 0) {
      return NextResponse.json({ error: 'No valid fields' }, { status: 400 });
    }

    const set = entries.map(([k]) => `${k} = ?`).join(', ');
    const vals = entries.map(([, v]) => v);

    db.prepare(`UPDATE leads SET ${set} WHERE id = ?`).run(...vals, params.id);
    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(params.id);
    return NextResponse.json(lead);
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(request, { params }) {
  try {
    const db = getDb();
    db.prepare('DELETE FROM leads WHERE id = ?').run(params.id);
    return NextResponse.json({ deleted: parseInt(params.id) });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
