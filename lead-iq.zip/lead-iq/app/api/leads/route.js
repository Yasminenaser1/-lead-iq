import { NextResponse } from 'next/server';
import getDb from '@/lib/db';

export async function GET() {
  try {
    const db = getDb();
    const leads = db.prepare('SELECT * FROM leads ORDER BY created_at DESC').all();
    return NextResponse.json(leads);
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { company, contact_name, email, title, company_size, notes } = body;

    if (!company || !contact_name) {
      return NextResponse.json(
        { error: 'company and contact_name are required' },
        { status: 400 }
      );
    }

    const db = getDb();
    const result = db.prepare(`
      INSERT INTO leads (company, contact_name, email, title, company_size, notes)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(company, contact_name, email || '', title || '', company_size || '', notes || '');

    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(result.lastInsertRowid);
    return NextResponse.json(lead, { status: 201 });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
