import { NextResponse } from 'next/server';
import getDb from '@/lib/db';
import Groq from 'groq-sdk';

export async function POST(request) {
  try {
    const { leadId } = await request.json();
    const db = getDb();
    const lead = db.prepare('SELECT * FROM leads WHERE id = ?').get(leadId);

    if (!lead) {
      return NextResponse.json({ error: 'Lead not found' }, { status: 404 });
    }

    const groqKey = process.env.GROQ_API_KEY;

    // No API key — return a demo score
    if (!groqKey || groqKey === 'paste_your_key_here') {
      const score = Math.floor(Math.random() * 4) + 5; // 5-8
      const reason = 'Demo mode — add your GROQ_API_KEY to .env.local for real AI scoring';
      db.prepare('UPDATE leads SET score = ?, score_reason = ? WHERE id = ?')
        .run(score, reason, lead.id);
      const updated = db.prepare('SELECT * FROM leads WHERE id = ?').get(lead.id);
      return NextResponse.json({ score, reason, lead: updated });
    }

    const client = new Groq({ apiKey: groqKey });

    const prompt = `You are a B2B sales qualification expert for coffee shop equipment, supplies, and services.

Score this lead from 1-10 on likelihood to become a paying customer:

Company: ${lead.company}
Contact: ${lead.contact_name}${lead.title ? ` (${lead.title})` : ''}
Size: ${lead.company_size || 'Unknown'}
Notes: ${lead.notes || 'None'}

Scoring guide:
- 9-10: Decision maker at a growing coffee chain or large single location with clear budget
- 7-8: Owner or ops manager at a mid-size shop, genuine interest
- 5-6: Staff member or small independent, possible but slow conversion
- 1-4: Wrong fit, no authority, or very low spend potential

Reply in this exact JSON only — no extra text:
{"score": 7, "reason": "One concise sentence explaining the score."}`;

    const completion = await client.chat.completions.create({
      model: 'llama3-8b-8192',
      messages: [{ role: 'user', content: prompt }],
      max_tokens: 120,
      temperature: 0.3,
    });

    const raw = completion.choices[0].message.content.trim();
    const match = raw.match(/\{[\s\S]*?\}/);
    if (!match) throw new Error('Bad JSON from Groq: ' + raw);

    const { score, reason } = JSON.parse(match[0]);

    db.prepare('UPDATE leads SET score = ?, score_reason = ? WHERE id = ?')
      .run(score, reason, lead.id);
    const updated = db.prepare('SELECT * FROM leads WHERE id = ?').get(lead.id);

    return NextResponse.json({ score, reason, lead: updated });
  } catch (err) {
    console.error('Score error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
